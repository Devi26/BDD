

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.cg.hotelbooking.HotelBookingMaintainable;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.HotelBookingPageFactory;

public class HotelBookingStepDefs {

	private WebDriver driver;
	private HotelBookingPageFactory objhbpg ;

	@Before
	public void openBrowser() {
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhbpg = new HotelBookingPageFactory(driver);
		driver.get("file:///D:/168360_Devi_Ratnala/BDD/App_HotelBooking/hotelbooking.html");
	}

	@Given("^User is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhbpg = new HotelBookingPageFactory(driver);
		driver.get("file:///D:/168360_Devi_Ratnala/BDD/App_HotelBooking/hotelbooking.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {

		String title = driver.getTitle();
		if(title.contentEquals("Hotel Booking"))
			System.out.println("****** Title Matched");
		else
			System.out.println("****** Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {

		objhbpg.setPffname("Devi"); Thread.sleep(1000);
		objhbpg.setPflname("Ratnala"); Thread.sleep(1000);
		objhbpg.setPfemail("dssri.26@gmail.com");  Thread.sleep(1000);
		objhbpg.setPfmobile("9989189217");  Thread.sleep(1000);
		objhbpg.setPfcity("Pune"); Thread.sleep(1000);
		objhbpg.setPfstate("Maharastra"); Thread.sleep(1000);
		objhbpg.setPfpersons("5"); Thread.sleep(1000);
		objhbpg.setPfrooms("2"); Thread.sleep(1000);
		objhbpg.setPfcardholder("Devi Surya Sri Ratnala"); Thread.sleep(1000);
		objhbpg.setPfdebit("5678567867897890"); Thread.sleep(1000);
		objhbpg.setPfcvv("067"); Thread.sleep(1000);
		objhbpg.setPfmonth("12"); Thread.sleep(1000);
		objhbpg.setPfyear("2020"); Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		objhbpg.setPfbutton();
		driver.close();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
		driver.navigate().to("file:///D:/168360_Devi_Ratnala/BDD/App_HotelBooking/success.html");
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user leaves first Name blank$")
	public void user_leaves_first_Name_blank() throws Throwable {
		objhbpg.setPffname(""); 
		Thread.sleep(1000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
		objhbpg.setPfbutton();
		Thread.sleep(1000);
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}

	@When("^user leaves last Name blank and clicks the button$")
	public void user_leaves_last_Name_blank_and_clicks_the_button() throws Throwable {
		objhbpg.setPffname("Devi");  Thread.sleep(1000);
		objhbpg.setPflname("");   Thread.sleep(1000);
		objhbpg.setPfbutton();
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {

	}

	@When("^user enters incorrect email format and clicks the button$")
	public void user_enters_incorrect_email_format_and_clicks_the_button() throws Throwable {

	}

	@When("^user leaves MobileNo blank and clicks the button$")
	public void user_leaves_MobileNo_blank_and_clicks_the_button() throws Throwable {

	}

	@When("^user enters incorrect mobileNo format and clicks the button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {

	}

	@When("^user doesnot select city$")
	public void user_doesnot_select_city() throws Throwable {

	}

	@When("^user doesnot select state$")
	public void user_doesnot_select_state() throws Throwable {

	}

	@When("^user enters (\\d+)$")
	public void user_enters(int arg1) throws Throwable {

	}

	@Then("^allocate rooms such that (\\d+) room for minimum (\\d+) guests$")
	public void allocate_rooms_such_that_room_for_minimum_guests(String arg1, String arg2) throws Throwable {

	}

	@When("^user leaves CardHolderName blank and clicks the button$")
	public void user_leaves_CardHolderName_blank_and_clicks_the_button() throws Throwable {

	}

	@When("^user leaves DebitCardNo blank and clicks the button$")
	public void user_leaves_DebitCardNo_blank_and_clicks_the_button() throws Throwable {

	}

	@When("^user leaves expirationMonth blank and clicks the button$")
	public void user_leaves_expirationMonth_blank_and_clicks_the_button() throws Throwable {

	}

	@When("^user leaves expirationYr blank and clicks the button$")
	public void user_leaves_expirationYr_blank_and_clicks_the_button() throws Throwable {

	}
}
