package com.cg.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="features", glue="com.cg.stepdefs", tags= {"@tag4"})
public class TestRunner {

}

/*1. ~ is used for eliminating the particular tag in the execution
 	 EX: tags= {"@tag2","~@tag3"}
  2. whatever we using in the " " will be executed
     Ex: tags={"@tag1,@tag2"}--Here both will execute--AND OPERATION takes place
     Ex: tags={"@tag1","@tag2"}--Here any one will execute--OR OPERATION takes place
  3. @Before, @After are known as HOOKS*/ 