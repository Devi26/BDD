package com.cg.math;
public class Calculator {

	public int add(int i, int j) {

		if(i<=0 || j<=0)
			return -1;	
		return i+j;
	}
	public int findSquare(int arg1) {
		return arg1*arg1;
	}
}

