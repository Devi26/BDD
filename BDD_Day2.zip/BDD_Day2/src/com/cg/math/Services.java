package com.cg.math;

import java.util.List;
import java.util.regex.Pattern;

public class Services {

	public String validateMobileList(List<String> list) {
		boolean flag = false;
		String regex = "^[0-9]{10}$";
		for (String mobNo : list) {

			if(Pattern.matches(regex, mobNo)==false) {

				flag=true;
				break;
			} 
		}
		String message;
		if (flag) {
			message = "Invalid Numbers are present in Data Table";
		}
		else
			message = "All Numbers are valid";
		return message;
	}
}
