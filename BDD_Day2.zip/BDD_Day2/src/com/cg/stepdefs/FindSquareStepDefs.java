package com.cg.stepdefs;

import static org.testng.Assert.assertEquals;

import com.cg.math.Calculator;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FindSquareStepDefs {
	
	Calculator cal1;
	int res;
	int errorCode;
	
	@Before
	public void beforeMethod() {
		System.out.println("I am in before method.......");
	}
	@After
	public void afterMethod() {
		System.out.println("I am in after method.......");
	}

	@Given("^Create the Calculator Object$")
	public void create_the_Calculator_Object() throws Throwable {
	   
		cal1 = new Calculator();
		System.out.println("I am in Given step.......");	
	}

	@When("^User given valid (\\d+) to findSquare method$")
	public void user_given_valid_to_findSquare_method(int arg1) throws Throwable {
	    
		res = cal1.findSquare(arg1);
		System.out.println("I am in When step.......");
		
	}

	@Then("^method should return correct (\\d+)$")
	public void method_should_return_correct(int arg1) throws Throwable {
	    
		assertEquals(res, arg1);
		System.out.println("I am in Then step.......");
	}
}
