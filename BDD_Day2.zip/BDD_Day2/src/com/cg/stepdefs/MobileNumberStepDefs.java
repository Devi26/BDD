package com.cg.stepdefs;


import static org.testng.Assert.assertEquals;

import java.util.List;

import com.cg.math.Services;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MobileNumberStepDefs {

	Services service;
	String message = "";

	@Given("^create the service object$")
	public void create_the_service_object() throws Throwable {

		service  = new Services();
	}

	@When("^user will enter correct mobile number$")
	public void user_will_enter_correct_mobile_number(DataTable arg1) throws Throwable {

		List<String> list = arg1.asList(String.class);

		message = service.validateMobileList(list);
	}

	@Then("^method should return success message$")
	public void method_should_return_success_message() throws Throwable {

		assertEquals(message, "All Numbers are valid");

	}
}
