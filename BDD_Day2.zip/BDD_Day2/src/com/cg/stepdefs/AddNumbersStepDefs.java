package com.cg.stepdefs;

import static org.testng.Assert.assertEquals;

import com.cg.math.Calculator;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddNumbersStepDefs {

	Calculator cal1;
	int res;
	int errorCode;
	
	@Given("^user creates Calculator object and call add method$")
	public void user_creates_Calculator_object_and_call_add_method() throws Throwable {
	    
		cal1 = new Calculator();
		
	}

	@When("^user will pass valid input$")
	public void user_will_pass_valid_input() throws Throwable {
	    
		res = cal1.add(10,20);
		
	}

	@Then("^add method should return correct result$")
	public void add_method_should_return_correct_result() throws Throwable {
	   
		assertEquals(res, 30);
	}

	@When("^user will pass one valid and one invalid input$")
	public void user_will_pass_one_valid_and_one_invalid_input() throws Throwable {
	  
		errorCode = cal1.add(10, -6);
		
	}

	@Then("^add method should return error code$")
	public void add_method_should_return_error_code() throws Throwable {
	
		assertEquals(errorCode, -1);
	}
}
