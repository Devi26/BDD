import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

	public class WorkingWithForms {
		public static void main(String[] args) {
			WebDriver driver = new FirefoxDriver();
			driver.get("file:///D:/Users/ADM-IG-HWDLAB2E/Desktop/Lesson%205-HTML%20Pages/WorkingWithForms.html");
			try {

				//find Username and enter value
				driver.findElement(By.id("txtUserName")).sendKeys("Devi@1234");
				Thread.sleep(1000);

				//find Password textbox and enter value
				driver.findElement(By.name("txtPassword")).sendKeys("igate");
				Thread.sleep(1000);

				//find Confirm Password textbox and enter value
				driver.findElement(By.className("txtConfPassword")).sendKeys("igate");
				Thread.sleep(1000);	
			} catch (Exception e) {

				System.out.println("Some exception");
			}

			//find First Name and enter value
			driver.findElement(By.cssSelector("input.Format1")).sendKeys("Devi");

			//find Last Name and enter value
			driver.findElement(By.name("txtLN")).sendKeys("Ratnala");

			//find Gender radio button and enter value
			driver.findElement(By.cssSelector("input[value='Male']")).click();

			//find date of birth text box and enter value
			driver.findElement(By.name("DtOB")).sendKeys("26/01/1996");

			//find Email text box and enter value
			driver.findElement(By.name("Email")).sendKeys("dssri.26@gmail.com");

			//find Address text box and enter value
			driver.findElement(By.name("Address")).sendKeys("Pune");

			//Select drpCity = new Select(driver.findElement(By.name("city")));
			Select drpCity = new Select(driver.findElement(By.cssSelector("city")));

			//find phone textbox and enter value
			//driver.findElement(By.xpath("//html/body/form/table/")).sendKeys("9989189217");
			driver.findElement(By.xpath(".//[@id='txtPhone']")).sendKeys("9989189217");

			List<WebElement> element =  driver.findElements(By.name("chkHobbies"));

			for (WebElement val : element) {

				val.click();

				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					System.out.println(e.getMessage());
				}
			}
			
			//Examples of Get commands
			
			String actualTitle;
			actualTitle = driver.getTitle();
			System.out.println("The page title is: " + actualTitle);
			String expectedTitle = "Email";
		}
	}

