package HotelLogin;

import static org.junit.Assert.assertTrue;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import PageBean.HotelLoginPageFactory;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefHotelLogin {
	private WebDriver driver;
	private HotelLoginPageFactory objhlpf;

	@Before
	public void openBrowsser() {
		String driverPath = "D:\\168360_Devi_Ratnala\\BDD\\chromedriver\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		objhlpf = new HotelLoginPageFactory(driver);
		driver.get("file:///D:/168360_Devi_Ratnala/BDD/App_HotelLogin/login.html");
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {

		String strheading = driver.findElement(By.xpath("//*[@id='mainCnt']/div[1]/div[1]/h1")).getText();
		if(strheading.contentEquals("Hotel Booking Application")) 
		{
			System.out.println("Heading Matched");
		}
		else
		{
			System.out.println("Heading Not Matched");
		}
	}

	@When("^user not entered username$")
	public void user_not_entered_username() throws Throwable {
		objhlpf.setPfUName("");  Thread.sleep(1000);
	}

	@When("^clicks the Login Button$")
	public void clicks_the_Login_Button() throws Throwable {
		objhlpf.setPfLogin();  Thread.sleep(1000);
	}

	@Then("^display error message for username$")
	public void display_error_message_for_username() throws Throwable {
		/*JavascriptExecutor js = (JavascriptExecutor) driver;
		System.out.println("Text on home page is  : " + js.executeScript("return document.getElementById('userErrMsg').innerHTML").toString());*/
		
		String error = driver.findElement(By.xpath("//*[@id='userErrMsg']")).getText();
		System.out.println("The error message is : " + error);
	}

	@Then("^display error message for password$")
	public void display_error_message_for_password() throws Throwable {
		/*JavascriptExecutor js = (JavascriptExecutor) driver;
		System.out.println("Text on home page is  : " + js.executeScript("return document.getElementById('pwdErrMsg').innerHTML").toString());*/
		
		String error = driver.findElement(By.xpath("//*[@id='pwdErrMsg']")).getText();
		System.out.println("The error message is : " + error);
	}

	@When("^user not entered password$")
	public void user_not_entered_password() throws Throwable {
		objhlpf.setPfUName("cg");
		objhlpf.setPfPwd("");  Thread.sleep(1000);
	}

	@When("^user enters invalid username or password$")
	public void user_enters_invalid_username_or_password() throws Throwable {
		objhlpf.setPfUName("cg"); 
		objhlpf.setPfPwd("caffgg1234");  
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		objhlpf.setPfLogin();  Thread.sleep(1000);
	}

	@Then("^display login failed message$")
	public void display_login_failed_message() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("******" + alertMessage + "*******");
	}

	@When("^user enetrs valid username and password$")
	public void user_enetrs_valid_username_and_password() throws Throwable {
		objhlpf.setPfUName("capgemini"); 
		objhlpf.setPfPwd("capg1234");  
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		objhlpf.setPfLogin();  Thread.sleep(1000);
	}

	@Then("^navigate to Hotel Booking$")
	public void navigate_to_Hotel_Booking() throws Throwable {
		driver.navigate().to("file:///D:/168360_Devi_Ratnala/BDD/App_HotelLogin/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@After
	public void closeBrowser() {
		driver.close();
	}
}


/*@Then("^display error message$")
public void display_error_message() throws Throwable {

	assertTrue(driver.getPageSource().contains("* Please enter "));

	String alertMessage = driver.switchTo().alert().getText();
	Thread.sleep(1000);
	driver.switchTo().alert().accept();
	System.out.println("******" + alertMessage + "*******");

	JavascriptExecutor js = (JavascriptExecutor) driver;
	System.out.println("Tect on home page is  : " + js.executeScript("return document.getElementById('userErrMsg').innerHTML").toString());
}*/
