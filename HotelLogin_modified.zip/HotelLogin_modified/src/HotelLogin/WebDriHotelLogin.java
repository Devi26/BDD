package HotelLogin;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriHotelLogin {
	static WebDriver driver=null;
	static String alertMessage=null;

	public static void main(String[] args) {

		String driverPath = "D:\\168360_Devi_Ratnala\\BDD\\chromedriver\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("file:///D:/168360_Devi_Ratnala/BDD/App_HotelLogin/login.html");

		String title = driver.getTitle();
		System.out.println("The page title is :" + title);

		/******* For blank User Name *******/	
		driver.findElement(By.name("userName")).sendKeys("");
		driver.findElement(By.className("btn")).click();
		String Error=driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText();
		System.out.println("The error msg is," + Error);
		
		/******* For valid User Name *******/
		driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userName")).sendKeys("capgemini");

		
		/******* For blank password *******/
		driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		driver.findElement(By.name("userPwd")).sendKeys("");
		driver.findElement(By.className("btn")).click();
		String Error2=driver.findElement(By.xpath(".//*[@id='pwdErrMsg']")).getText();
		System.out.println("The error msg is," + Error2);
		
		/******* For  valid   password *******/	
		driver.findElement(By.name("userPwd")).clear();
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		
		/******* For Invalid User Name *******/
		driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userName")).sendKeys("cap");
		driver.findElement(By.name("userPwd")).clear();
		driver.findElement(By.name("userPwd")).sendKeys("cgdgh");
		driver.findElement(By.className("btn")).click();
		callAlert();
		
		/****entered all valid data. Now its time to navigate to next page****/
		driver.findElement(By.className("btn")).click();
		driver.navigate().to("file:///D:/168360_Devi_Ratnala/BDD/App_HotelLogin/success.html");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	public static void callAlert() {
		String alertMessage = driver.switchTo().alert().getText();
		System.out.println(alertMessage);
		driver.switchTo().alert().accept();
	}
}
