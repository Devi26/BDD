package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HotelLoginPageFactory {

	WebDriver driver;

	//initiating the elements
	
	public HotelLoginPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	//step 1 : identify elements

	//@FindBy(name="userName")
	@FindBy(how=How.NAME, using="userName")
	@CacheLookup
	WebElement pfUName;

	@FindBy(name="userPwd")
	@CacheLookup
	WebElement pfPwd;

	@FindBy(className="btn")
	@CacheLookup
	WebElement pfLogin;

	//step 2 : Setters
	
	public void setPfUName(String spfUName) {
		pfUName.sendKeys(spfUName);
	}

	public void setPfPwd(String spfPwd) {
		pfPwd.sendKeys(spfPwd);
	}

	public void setPfLogin() {
		pfLogin.click();
	}

	//step 3 : Getters
	
	public WebElement getPfUName() {
		return pfUName;
	}

	public WebElement getPfPwd() {
		return pfPwd;
	}

	public WebElement getPfLogin() {
		return pfLogin;
	}
}
