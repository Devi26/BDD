import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumHotelBookingMaintainable {

	
		// TODO Auto-generated method stub
		static WebDriver driver=null;
		static String alertMessage=null;
		
		public static void main(String[] args) {
			driver = new FirefoxDriver();
			driver.get("file:///D:/168360_Devi_Ratnala/BDD/App_HotelBooking/hotelbooking.html");

			String title=driver.getTitle();
			System.out.println("The page title is :" + title);
			
			driver.findElement(By.name("txtFN")).sendKeys("Devi");
			driver.findElement(By.id("btnPayment")).click();
			
			String alertMessage= driver.switchTo().alert().getText();
			System.out.println(alertMessage);		
			driver.switchTo().alert().accept();



	}

}
