package HotelLogin;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebDHotelLogin {

	static WebDriver driver=null;
	static String alertMessage=null;

	public static void main(String[] args) {

		String driverPath = "D:\\168360_Devi_Ratnala\\BDD\\chromedriver\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	

		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.get("file:///D:/168360_Devi_Ratnala/BDD/App_HotelBooking/login.html");

		/*String strheading = driver.findElement(By.xpath("//*[@id='mainCnt']/div[1]/div[1]/h1")).getText();
		if(strheading.contentEquals("Hotel Booking Application")) 
		{
			System.out.println("Heading Matched");
		}
		else
		{
			System.out.println("Heading Not Matched");
		}*/

		String title = driver.getTitle();
		System.out.println("The page title is :" + title);

		/******* For blank User Name *******/
		driver.findElement(By.name("userName")).sendKeys("");
		driver.findElement(By.className("btn")).click();
		callAlert();

		/******* For valid User Name *******/
		driver.findElement(By.name("userName")).sendKeys("Capgemini");

		/******* For blank password *******/

		driver.findElement(By.name("userPwd")).sendKeys("");
		driver.findElement(By.className("btn")).click();
		callAlert();

		/******* For  valid   password *******/
		driver.findElement(By.name("userPwd")).sendKeys("Capge@123");

		/****entered all valid data. Now its time to navigate to next page****/
		driver.findElement(By.className("btn")).click();
		driver.navigate().to("file:///D:/168360_Devi_Ratnala/BDD/App_HotelBooking/success.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public static void callAlert()
	{
		String alertMessage= driver.switchTo().alert().getText();
		System.out.println(alertMessage);		
		driver.switchTo().alert().accept();
	}
}