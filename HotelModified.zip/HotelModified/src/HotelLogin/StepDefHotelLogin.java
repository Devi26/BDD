package HotelLogin;

import static org.testng.Assert.assertEquals;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.HotelLogPgFactory;

public class StepDefHotelLogin {
	private WebDriver driver;
	private HotelLogPgFactory objhlpf;

	@Before
	public void openBrowsser() {
		String driverPath = "D:\\168360_Devi_Ratnala\\BDD\\chromedriver\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		objhlpf = new HotelLogPgFactory(driver);
		driver.get("file:///D:/168360_Devi_Ratnala/BDD/App_HotelBooking/login.html");
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {

		String strheading = driver.findElement(By.xpath("//*[@id='mainCnt']/div[1]/div[1]/h1")).getText();
		if(strheading.contentEquals("Hotel Booking Application")) 
		{
			System.out.println("Heading Matched");
		}
		else
		{
			System.out.println("Heading Not Matched");
		}
	}

	@When("^user enters valid username, valid password$")
	public void user_enters_valid_username_valid_password() throws Throwable {
		objhlpf.setPfuname("capgemini"); 	Thread.sleep(1000);
		objhlpf.setPfpwd("capg1234");  Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		objhlpf.setPflogin();
	}

	@Then("^navigate to hotelBooking$")
	public void navigate_to_hotelBooking() throws Throwable {
		driver.navigate().to("file:///D:/168360_Devi_Ratnala/BDD/App_HotelBooking/success.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^user doesnot enter either username or password$")
	public void user_doesnot_enter_either_username_or_password() throws Throwable {
		objhlpf.setPfuname("");  Thread.sleep(1000);
		objhlpf.setPfpwd("");  Thread.sleep(1000);
	}

	@When("^clicks the Login Button$")
	public void clicks_the_Login_Button() throws Throwable {
		objhlpf.setPflogin();
	}

	@Then("^display appropriate messaage$")
	public void display_appropriate_messaage() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("******" + alertMessage);
	}

	@When("^user enters incorrect username or password$")
	public void user_enters_incorrect_username_or_password() throws Throwable {
		objhlpf.setPfuname("devi.com");  Thread.sleep(1000);
		objhlpf.setPfpwd("fg");  Thread.sleep(1000);
		objhlpf.setPflogin();
	}

	@Then("^display login failed message$")
	public void display_login_failed_message() throws Throwable {
		/*String strheading = driver.findElement(By.xpath("//*[@id='userErrMsg']")).getText();
		assertEquals(strheading,  "* Please enter correct Credentials.");*/
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("******" + alertMessage);
	}
	@After
	public void closeBrowser() {
		driver.close();
	}

}
